function changeText() {
    var paragraph = document.getElementById("output");
    paragraph.innerHTML = "Have fun!";
}
